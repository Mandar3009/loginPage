// import logo from './logo.svg';
import './App.css';
import MultipleInputs from './components/forms/MultipleInputs';

function App() {
  return (
    <div className="App">
    <MultipleInputs/>
    </div>
  );
}

export default App;
