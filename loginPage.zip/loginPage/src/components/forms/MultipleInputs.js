import React, { useState } from 'react'

const MultipleInputs=()=>{
    const [userRegistration,setuserRegsitration]=useState({
        username:"",
        mail:"",
        phone:"",
        password:""


    })
    const [records,setRecords]=useState([]);

    const handelInput=(e)=>{
        const name=e.target.name;
        const value=e.target.value;
        setuserRegsitration({...userRegistration,[name]:value })
    }
    const handleSubmit=(e)=>{
        e.preventDefault();

        const newRecord={...userRegistration,id:new Date().getTime().toString()}

        setRecords([...records,newRecord])
        console.log(records)

    }
    return (
        <>
        <form action='' onSubmit={handleSubmit}>
            <div>
                <label htmlFor='username'>Username</label>
                <input type="text" autoComplete='off' name='username' id='username'
                value={userRegistration.username}
                onChange={handelInput}></input>
            </div>
            <div>
                <label htmlFor='email'>Email</label>
                <input type="text" autoComplete='off' name='mail' id='mail'
                 value={userRegistration.mail}
                 onChange={handelInput}></input>
            </div>
            <div>
                <label htmlFor='phone'>Phone</label>
                <input type="text" autoComplete='off' name='phone' id='phone'
                 value={userRegistration.phone}
                 onChange={handelInput}></input>
            </div>
            <div>
                <label htmlFor='password'>Password</label>
                <input type="text" autoComplete='off' name='password' id='password'
                 value={userRegistration.password}
                 onChange={handelInput}></input>
            </div>

            <button type='submit'>Register</button>

        </form>
        </>
    )
}
export default MultipleInputs